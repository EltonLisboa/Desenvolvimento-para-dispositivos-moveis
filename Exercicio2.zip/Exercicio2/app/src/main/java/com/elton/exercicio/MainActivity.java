package com.elton.exercicio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText dollarText, realText;
    private Button converterButton;
    private RadioGroup rgGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dollarText = findViewById(R.id.dollarText);
        realText = findViewById(R.id.realText);
        rgGroup = findViewById(R.id.rdgroup);
        converterButton = findViewById(R.id.converterButton);

        converterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String dollarString = dollarText.getText().toString();
                String realString = realText.getText().toString();

                int rgConversao = rgGroup.getCheckedRadioButtonId();
                switch (rgConversao){
                    case R.id.dollarButton:
                        rgConversao = 1;
                        break;
                    case R.id.realButton:
                        rgConversao = 2;
                        break;
                }
                Double cotacao = 2.10;
                if (rgConversao == 1){

                    Double dollar = Double.parseDouble(dollarString.replace(".",","));
                    Double resultado = dollar * cotacao;
                    DecimalFormat df = new DecimalFormat();
                    df.applyPattern("0");
                    realText.setText(df.format(resultado));
                }else
                    if(rgConversao == 2){
                    Double real = Double.parseDouble(realString.replace(",","."));
                    Double resultado = real / cotacao;
                    DecimalFormat df = new DecimalFormat();
                    df.applyPattern("0");
                    dollarText.setText(df.format(resultado));
                }

            }
        });



























        /*
        rdGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override

            public void onCheckedChanged(RadioGroup group, int checkedId) {


                if (rdButton.isChecked()){

                }
            }

        });



        realText.setText(" ");
        dollarText.setText("");

        converterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double dollar = 0.0;
                Double real = 0.0;

                dollar = Double.parseDouble( dollarText.getText().toString());
                real = Double.parseDouble(realText.getText().toString());
                if(rdButton.isChecked() || realText.equals("")){
                    realText.setText(String.valueOf(dollar * 2.10));

                } else
                    if (realText.equals("")){
                    dollarText.setText(String.valueOf(real / 2.10));


                }
            }
        });

    }**/
}
}
